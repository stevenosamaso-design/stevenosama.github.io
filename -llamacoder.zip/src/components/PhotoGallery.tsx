import { useState, useEffect } from 'react'
import { Heart, ArrowLeft } from 'lucide-react'
import { Button } from '../components/ui/button'

interface PhotoGalleryProps {
  onLogout: () => void
}

// Placeholder image data - in a real app, these would be actual images
const photos = [
  { id: 1, title: 'First Meeting', date: '2020' },
  { id: 2, title: 'Summer Adventure', date: '2021' },
  { id: 3, title: 'Coffee Dates', date: '2021' },
  { id: 4, title: 'Road Trip', date: '2022' },
  { id: 5, title: 'Birthday Celebration', date: '2022' },
  { id: 6, title: 'Winter Walks', date: '2023' },
  { id: 7, title: 'Sunset Views', date: '2023' },
  { id: 8, title: 'Anniversary', date: '2024' },
  { id: 9, title: 'Lazy Sundays', date: '2024' },
]

export default function PhotoGallery({ onLogout }: PhotoGalleryProps) {
  const [loadedImages, setLoadedImages] = useState<Set<number>>(new Set())

  useEffect(() => {
    // Preload first few images
    const preloadImages = [1, 2, 3]
    preloadImages.forEach(id => {
      const img = new Image()
      img.onload = () => {
        setLoadedImages(prev => new Set(prev).add(id))
      }
      img.src = `https://picsum.photos/seed/moment${id}/400/400.jpg`
    })
  }, [])

  const handleImageLoad = (id: number) => {
    setLoadedImages(prev => new Set(prev).add(id))
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-red-600 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Heart className="w-6 h-6 text-red-600" />
              <div>
                <h1 className="text-xl font-serif text-red-900">Our Moments</h1>
                <p className="text-sm text-red-600">2020 – 2024</p>
              </div>
            </div>
            <Button
              variant="secondary"
              onClick={onLogout}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Lock Gallery
            </Button>
          </div>
        </div>
      </header>

      {/* Gallery Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl bg-white shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-red-100"
              style={{
                animationDelay: `${index * 100}ms`,
              }}
            >
              <div className="aspect-square">
                <img
                  src={`https://picsum.photos/seed/moment${photo.id}/400/400.jpg`}
                  alt={photo.title}
                  loading={index < 3 ? 'eager' : 'lazy'}
                  onLoad={() => handleImageLoad(photo.id)}
                  className={`w-full h-full object-cover transition-opacity duration-500 ${
                    loadedImages.has(photo.id) ? 'opacity-100' : 'opacity-0'
                  }`}
                />
                {!loadedImages.has(photo.id) && (
                  <div className="absolute inset-0 bg-red-200 animate-pulse" />
                )}
              </div>
              
              {/* Overlay Info */}
              <div className="absolute inset-0 bg-gradient-to-t from-red-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                  <h3 className="font-medium text-lg">{photo.title}</h3>
                  <p className="text-sm opacity-90">{photo.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Quote */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center space-x-2 text-white bg-red-600 px-6 py-3 rounded-full">
            <Heart className="w-4 h-4" />
            <p className="text-sm font-medium">
              "Every moment with you is a treasure"
            </p>
            <Heart className="w-4 h-4" />
          </div>
        </div>
      </main>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </div>
  )
}