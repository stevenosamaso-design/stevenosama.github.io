import { useState } from 'react'
import { Heart } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'

interface PasswordGateProps {
  onAuthenticate: (success: boolean) => void
}

const CORRECT_PASSWORD = 'friendship2024'

export default function PasswordGate({ onAuthenticate }: PasswordGateProps) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError('')

    // Simulate a brief delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500))

    if (password === CORRECT_PASSWORD) {
      onAuthenticate(true)
    } else {
      setError('That\'s not quite right... try again')
      setPassword('')
    }
    setIsSubmitting(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
        {/* Logo/Icon Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-red-100 rounded-full mb-4 animate-pulse">
            <Heart className="w-10 h-10 text-red-600" />
          </div>
          <h1 className="text-3xl font-serif text-red-900 mb-2">Our Moments</h1>
          <p className="text-red-600 text-sm">A private collection of memories</p>
        </div>

        {/* Password Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="password" className="text-red-700 font-medium">
              Enter the password to continue
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="border-red-200 focus:border-red-400 focus:ring-red-200"
              disabled={isSubmitting}
              autoComplete="off"
            />
          </div>

          {error && (
            <div className="animate-fadeIn">
              <p className="text-red-600 text-sm text-center">{error}</p>
            </div>
          )}

          <Button
            type="submit"
            disabled={!password || isSubmitting}
            className="w-full bg-red-600 hover:bg-red-700 text-white transition-colors duration-200"
          >
            {isSubmitting ? 'Opening...' : 'Unlock Memories'}
          </Button>
        </form>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-red-400 text-xs">
            These moments are meant for two hearts only
          </p>
        </div>
      </div>
    </div>
  )
}