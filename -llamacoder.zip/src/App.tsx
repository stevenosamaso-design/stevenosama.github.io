import { useState, useEffect } from 'react'
import PasswordGate from './components/PasswordGate'
import PhotoGallery from './components/PhotoGallery'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check localStorage for authentication state
    const authStatus = localStorage.getItem('authenticated')
    if (authStatus === 'true') {
      setIsAuthenticated(true)
    }
    setIsLoading(false)
  }, [])

  const handleAuthentication = (success: boolean) => {
    if (success) {
      localStorage.setItem('authenticated', 'true')
      setIsAuthenticated(true)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('authenticated')
    setIsAuthenticated(false)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-red-600 flex items-center justify-center">
        <div className="animate-pulse">
          <div className="w-12 h-12 bg-white rounded-full"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-red-600">
      {isAuthenticated ? (
        <PhotoGallery onLogout={handleLogout} />
      ) : (
        <PasswordGate onAuthenticate={handleAuthentication} />
      )}
    </div>
  )
}

export default App